"use client"

import React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Header } from "@/components/header"
import { FloatingBubbles } from "@/components/glass-bubble"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useCart } from "@/context/cart-context"
import { 
  ArrowLeft, 
  MapPin, 
  CreditCard, 
  Banknote, 
  Smartphone,
  Check,
  ShieldCheck
} from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"

type PaymentMethod = "cod" | "card" | "upi"

export default function CheckoutPage() {
  const router = useRouter()
  const { items, getDiscountedTotal, clearCart } = useCart()
  const [step, setStep] = useState(1)
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cod")
  const [isProcessing, setIsProcessing] = useState(false)
  
  const [addressData, setAddressData] = useState({
    fullName: "",
    phone: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
  })

  const [cardData, setCardData] = useState({
    cardNumber: "",
    cardName: "",
    expiry: "",
    cvv: "",
  })

  const [upiId, setUpiId] = useState("")

  const subtotal = getDiscountedTotal()
  const shipping = subtotal > 499 ? 0 : 49
  const total = subtotal + shipping

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setStep(2)
  }

  const handlePaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    // Simulate payment processing
    await new Promise(resolve => setTimeout(resolve, 2000))

    // Generate order ID
    const orderId = `BMC${Date.now().toString().slice(-8)}`
    
    // Store order in localStorage for tracking
    const order = {
      id: orderId,
      items,
      total,
      address: addressData,
      paymentMethod,
      status: "confirmed",
      date: new Date().toISOString(),
    }
    
    const existingOrders = JSON.parse(localStorage.getItem("bmc-orders") || "[]")
    localStorage.setItem("bmc-orders", JSON.stringify([order, ...existingOrders]))
    
    clearCart()
    setIsProcessing(false)
    
    // Redirect to success page
    router.push(`/order-success?orderId=${orderId}`)
  }

  if (items.length === 0) {
    return (
      <div className="min-h-screen">
        <Header />
        <FloatingBubbles />
        <main className="pt-24 pb-16 px-4">
          <div className="max-w-md mx-auto text-center">
            <div className="rounded-3xl backdrop-blur-xl bg-card/80 border border-border p-12">
              <h1 className="text-2xl font-bold text-foreground mb-4">Cart is Empty</h1>
              <p className="text-muted-foreground mb-6">Add some products to checkout</p>
              <Link href="/shops">
                <Button>Start Shopping</Button>
              </Link>
            </div>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      <Header />
      <FloatingBubbles />
      
      <main className="pt-24 pb-16 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Back button */}
          <Link href="/cart">
            <Button variant="ghost" className="mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Cart
            </Button>
          </Link>

          {/* Progress Steps */}
          <div className="flex items-center justify-center mb-8">
            <div className="flex items-center">
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium",
                step >= 1 ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
              )}>
                {step > 1 ? <Check className="w-5 h-5" /> : "1"}
              </div>
              <span className="mx-2 text-sm text-muted-foreground">Address</span>
            </div>
            <div className={cn("w-12 h-0.5", step >= 2 ? "bg-primary" : "bg-secondary")} />
            <div className="flex items-center">
              <div className={cn(
                "w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium",
                step >= 2 ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
              )}>
                2
              </div>
              <span className="mx-2 text-sm text-muted-foreground">Payment</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Form */}
            <div className="lg:col-span-2">
              {step === 1 && (
                <div className="rounded-3xl backdrop-blur-xl bg-card/80 border border-border p-6">
                  <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-primary" />
                    Delivery Address
                  </h2>
                  
                  <form onSubmit={handleAddressSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="fullName">Full Name</Label>
                        <Input
                          id="fullName"
                          placeholder="John Doe"
                          value={addressData.fullName}
                          onChange={(e) => setAddressData({ ...addressData, fullName: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="phone">Phone Number</Label>
                        <Input
                          id="phone"
                          type="tel"
                          placeholder="+91 98765 43210"
                          value={addressData.phone}
                          onChange={(e) => setAddressData({ ...addressData, phone: e.target.value })}
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="address">Address</Label>
                      <Input
                        id="address"
                        placeholder="House/Flat No., Building, Street, Area"
                        value={addressData.address}
                        onChange={(e) => setAddressData({ ...addressData, address: e.target.value })}
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="city">City</Label>
                        <Input
                          id="city"
                          placeholder="Mumbai"
                          value={addressData.city}
                          onChange={(e) => setAddressData({ ...addressData, city: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="state">State</Label>
                        <Input
                          id="state"
                          placeholder="Maharashtra"
                          value={addressData.state}
                          onChange={(e) => setAddressData({ ...addressData, state: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="pincode">PIN Code</Label>
                        <Input
                          id="pincode"
                          placeholder="400001"
                          value={addressData.pincode}
                          onChange={(e) => setAddressData({ ...addressData, pincode: e.target.value })}
                          required
                        />
                      </div>
                    </div>
                    
                    <Button type="submit" className="w-full" size="lg">
                      Continue to Payment
                    </Button>
                  </form>
                </div>
              )}

              {step === 2 && (
                <div className="rounded-3xl backdrop-blur-xl bg-card/80 border border-border p-6">
                  <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-primary" />
                    Payment Method
                  </h2>
                  
                  {/* Payment Method Selection */}
                  <div className="grid grid-cols-3 gap-3 mb-6">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod("cod")}
                      className={cn(
                        "p-4 rounded-xl border-2 transition-all",
                        paymentMethod === "cod"
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50"
                      )}
                    >
                      <Banknote className={cn(
                        "w-6 h-6 mx-auto mb-2",
                        paymentMethod === "cod" ? "text-primary" : "text-muted-foreground"
                      )} />
                      <span className={cn(
                        "text-sm font-medium",
                        paymentMethod === "cod" ? "text-primary" : "text-muted-foreground"
                      )}>COD</span>
                    </button>
                    
                    <button
                      type="button"
                      onClick={() => setPaymentMethod("card")}
                      className={cn(
                        "p-4 rounded-xl border-2 transition-all",
                        paymentMethod === "card"
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50"
                      )}
                    >
                      <CreditCard className={cn(
                        "w-6 h-6 mx-auto mb-2",
                        paymentMethod === "card" ? "text-primary" : "text-muted-foreground"
                      )} />
                      <span className={cn(
                        "text-sm font-medium",
                        paymentMethod === "card" ? "text-primary" : "text-muted-foreground"
                      )}>Card</span>
                    </button>
                    
                    <button
                      type="button"
                      onClick={() => setPaymentMethod("upi")}
                      className={cn(
                        "p-4 rounded-xl border-2 transition-all",
                        paymentMethod === "upi"
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/50"
                      )}
                    >
                      <Smartphone className={cn(
                        "w-6 h-6 mx-auto mb-2",
                        paymentMethod === "upi" ? "text-primary" : "text-muted-foreground"
                      )} />
                      <span className={cn(
                        "text-sm font-medium",
                        paymentMethod === "upi" ? "text-primary" : "text-muted-foreground"
                      )}>UPI</span>
                    </button>
                  </div>

                  <form onSubmit={handlePaymentSubmit} className="space-y-4">
                    {paymentMethod === "cod" && (
                      <div className="p-4 rounded-xl bg-secondary/50 text-center">
                        <p className="text-muted-foreground">
                          Pay with cash when your order is delivered. An additional fee of Rs 20 may apply.
                        </p>
                      </div>
                    )}

                    {paymentMethod === "card" && (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="cardNumber">Card Number</Label>
                          <Input
                            id="cardNumber"
                            placeholder="1234 5678 9012 3456"
                            value={cardData.cardNumber}
                            onChange={(e) => setCardData({ ...cardData, cardNumber: e.target.value })}
                            required
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="cardName">Name on Card</Label>
                          <Input
                            id="cardName"
                            placeholder="John Doe"
                            value={cardData.cardName}
                            onChange={(e) => setCardData({ ...cardData, cardName: e.target.value })}
                            required
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <Label htmlFor="expiry">Expiry Date</Label>
                            <Input
                              id="expiry"
                              placeholder="MM/YY"
                              value={cardData.expiry}
                              onChange={(e) => setCardData({ ...cardData, expiry: e.target.value })}
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="cvv">CVV</Label>
                            <Input
                              id="cvv"
                              type="password"
                              placeholder="123"
                              maxLength={4}
                              value={cardData.cvv}
                              onChange={(e) => setCardData({ ...cardData, cvv: e.target.value })}
                              required
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {paymentMethod === "upi" && (
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <Label htmlFor="upiId">UPI ID</Label>
                          <Input
                            id="upiId"
                            placeholder="yourname@upi"
                            value={upiId}
                            onChange={(e) => setUpiId(e.target.value)}
                            required
                          />
                        </div>
                        <p className="text-sm text-muted-foreground">
                          You will receive a payment request on your UPI app.
                        </p>
                      </div>
                    )}

                    <div className="flex gap-3 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setStep(1)}
                        className="flex-1"
                      >
                        Back
                      </Button>
                      <Button
                        type="submit"
                        className="flex-1"
                        disabled={isProcessing}
                      >
                        {isProcessing ? "Processing..." : `Pay Rs ${Math.round(total).toLocaleString('en-IN')}`}
                      </Button>
                    </div>
                  </form>
                </div>
              )}
            </div>

            {/* Order Summary Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24 rounded-3xl backdrop-blur-xl bg-card/80 border border-border p-6">
                <h3 className="font-semibold text-foreground mb-4">Order Summary</h3>
                
                <div className="space-y-3 max-h-48 overflow-y-auto mb-4">
                  {items.map((item) => (
                    <div key={item.id} className="flex gap-3">
                      <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center flex-shrink-0">
                        <span className="text-sm font-bold text-primary/40">{item.name.charAt(0)}</span>
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">{item.name}</p>
                        <p className="text-xs text-muted-foreground">Qty: {item.quantity}</p>
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="border-t border-border pt-4 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Subtotal</span>
                    <span className="text-foreground">Rs {Math.round(subtotal).toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Shipping</span>
                    <span className="text-foreground">
                      {shipping === 0 ? <span className="text-green-600">FREE</span> : `Rs ${shipping}`}
                    </span>
                  </div>
                  <div className="flex justify-between text-lg font-bold pt-2 border-t border-border">
                    <span className="text-foreground">Total</span>
                    <span className="text-foreground">Rs {Math.round(total).toLocaleString('en-IN')}</span>
                  </div>
                </div>

                <div className="mt-4 p-3 rounded-lg bg-primary/5 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-primary" />
                  <span className="text-xs text-muted-foreground">Secure checkout with 256-bit encryption</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
