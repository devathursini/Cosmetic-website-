"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FloatingBubbles } from "@/components/glass-bubble"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { products, offers } from "@/lib/products-data"
import { Tag, Copy, Check } from "lucide-react"
import { useState } from "react"

export default function OffersPage() {
  const [copiedCode, setCopiedCode] = useState<string | null>(null)
  const discountedProducts = products.filter(p => p.discount)

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code)
    setCopiedCode(code)
    setTimeout(() => setCopiedCode(null), 2000)
  }

  return (
    <div className="min-h-screen">
      <Header />
      <FloatingBubbles />
      
      <main className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">Offers & Deals</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Discover amazing discounts on your favorite beauty products. Use coupon codes for extra savings!
            </p>
          </div>

          {/* Coupon Codes */}
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-foreground mb-6 flex items-center gap-2">
              <Tag className="w-6 h-6 text-primary" />
              Available Coupon Codes
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {offers.map((offer) => (
                <div
                  key={offer.id}
                  className="relative overflow-hidden rounded-2xl backdrop-blur-xl bg-card border-2 border-dashed border-primary/30 p-6"
                >
                  {/* Decorative bubble */}
                  <div className="absolute -top-6 -right-6 w-16 h-16 rounded-full bg-primary/10 backdrop-blur-sm" />
                  
                  <div className="relative z-10">
                    <div className="flex items-center justify-between mb-3">
                      <span className="px-3 py-1 rounded-full bg-primary/10 text-primary font-bold text-lg">
                        {offer.code}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyCode(offer.code)}
                        className="text-primary"
                      >
                        {copiedCode === offer.code ? (
                          <>
                            <Check className="w-4 h-4 mr-1" />
                            Copied!
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4 mr-1" />
                            Copy
                          </>
                        )}
                      </Button>
                    </div>
                    <p className="text-foreground font-medium">{offer.description}</p>
                    {offer.category && (
                      <p className="text-sm text-muted-foreground mt-1">Valid on {offer.category} products</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Discounted Products */}
          <div>
            <h2 className="text-2xl font-bold text-foreground mb-6">Products on Sale</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {discountedProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
