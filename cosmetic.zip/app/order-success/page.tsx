"use client"

import { Suspense } from "react"
import { useSearchParams } from "next/navigation"
import { Header } from "@/components/header"
import { FloatingBubbles } from "@/components/glass-bubble"
import { Button } from "@/components/ui/button"
import { CheckCircle, Package, ArrowRight } from "lucide-react"
import Link from "next/link"

function OrderSuccessContent() {
  const searchParams = useSearchParams()
  const orderId = searchParams.get("orderId")

  return (
    <div className="min-h-screen">
      <Header />
      <FloatingBubbles />
      
      <main className="pt-24 pb-16 px-4">
        <div className="max-w-lg mx-auto">
          <div className="relative overflow-hidden rounded-3xl backdrop-blur-xl bg-card/80 border border-border p-8 text-center">
            {/* Decorative bubbles */}
            <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-primary/10 backdrop-blur-sm" />
            <div className="absolute -bottom-8 -left-8 w-24 h-24 rounded-full bg-accent/10 backdrop-blur-sm" />
            
            <div className="relative z-10">
              {/* Success icon */}
              <div className="w-20 h-20 rounded-full bg-green-100 mx-auto mb-6 flex items-center justify-center">
                <CheckCircle className="w-12 h-12 text-green-600" />
              </div>
              
              <h1 className="text-2xl font-bold text-foreground mb-2">Order Confirmed!</h1>
              <p className="text-muted-foreground mb-6">
                Thank you for shopping with BMC. Your order has been placed successfully.
              </p>
              
              {orderId && (
                <div className="p-4 rounded-xl bg-secondary/50 mb-6">
                  <p className="text-sm text-muted-foreground">Order ID</p>
                  <p className="text-lg font-bold text-foreground">{orderId}</p>
                </div>
              )}
              
              <div className="space-y-4">
                <div className="p-4 rounded-xl border border-border flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <Package className="w-6 h-6 text-primary" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-foreground">Estimated Delivery</p>
                    <p className="text-sm text-muted-foreground">3-5 Business Days</p>
                  </div>
                </div>
              </div>
              
              <div className="flex flex-col gap-3 mt-8">
                <Link href={`/track${orderId ? `?orderId=${orderId}` : ''}`}>
                  <Button className="w-full" size="lg">
                    Track Order
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
                <Link href="/shops">
                  <Button variant="outline" className="w-full bg-transparent" size="lg">
                    Continue Shopping
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

export default function OrderSuccessPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    }>
      <OrderSuccessContent />
    </Suspense>
  )
}
