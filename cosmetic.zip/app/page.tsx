"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FloatingBubbles } from "@/components/glass-bubble"
import { ShopCard } from "@/components/shop-card"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { shops, products } from "@/lib/products-data"
import { ArrowRight, Sparkles, Truck, Shield, Gift } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  const featuredProducts = products.filter(p => p.discount).slice(0, 4)

  return (
    <div className="min-h-screen">
      <Header />
      <FloatingBubbles />
      
      <main className="pt-16">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-20 lg:py-32">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center max-w-3xl mx-auto">
              {/* Decorative bubbles */}
              <div className="absolute top-1/4 left-1/4 w-32 h-32 rounded-full bg-primary/10 backdrop-blur-sm -z-10" />
              <div className="absolute bottom-1/3 right-1/4 w-24 h-24 rounded-full bg-accent/10 backdrop-blur-sm -z-10" />
              
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-6">
                <Sparkles className="w-4 h-4" />
                <span className="text-sm font-medium">Premium Beauty Products</span>
              </div>
              
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 text-balance">
                Discover Your
                <span className="text-primary"> Perfect Beauty</span>
              </h1>
              
              <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
                Shop from India&apos;s most loved cosmetic brands. From Nykaa to MAC, find everything you need to enhance your natural beauty.
              </p>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link href="/shops">
                  <Button size="lg" className="px-8">
                    Explore Shops
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
                <Link href="/offers">
                  <Button size="lg" variant="outline" className="px-8 bg-transparent">
                    View Offers
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-16 bg-secondary/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                { icon: Truck, title: "Free Shipping", desc: "On orders above Rs 499" },
                { icon: Shield, title: "100% Authentic", desc: "Genuine products only" },
                { icon: Gift, title: "Special Offers", desc: "Daily deals & discounts" },
                { icon: Sparkles, title: "Easy Returns", desc: "7-day return policy" },
              ].map((feature, i) => (
                <div key={i} className="flex items-center gap-4 p-4 rounded-xl backdrop-blur-xl bg-card border border-border">
                  <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <feature.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{feature.title}</h3>
                    <p className="text-sm text-muted-foreground">{feature.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Shop Listings */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-foreground mb-4">Shop by Brand</h2>
              <p className="text-muted-foreground max-w-xl mx-auto">
                Explore our collection of premium cosmetic brands, each offering unique beauty solutions.
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {shops.map((shop) => (
                <ShopCard key={shop.id} {...shop} />
              ))}
            </div>
          </div>
        </section>

        {/* Featured Products */}
        <section className="py-20 bg-secondary/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-12">
              <div>
                <h2 className="text-3xl font-bold text-foreground mb-2">Hot Deals</h2>
                <p className="text-muted-foreground">Limited time offers on top products</p>
              </div>
              <Link href="/offers">
                <Button variant="outline">
                  View All
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="relative overflow-hidden rounded-3xl bg-primary p-8 md:p-12">
              {/* Decorative elements */}
              <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-white/10 -translate-y-1/2 translate-x-1/2" />
              <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full bg-white/5 translate-y-1/2 -translate-x-1/2" />
              
              <div className="relative z-10 text-center max-w-2xl mx-auto">
                <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
                  Join BMC Today
                </h2>
                <p className="text-primary-foreground/80 mb-8">
                  Sign up now and get Rs 100 off on your first order. Plus, exclusive member-only deals!
                </p>
                <Link href="/signup">
                  <Button size="lg" variant="secondary" className="px-8">
                    Create Account
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}
