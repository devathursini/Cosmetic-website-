"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FloatingBubbles } from "@/components/glass-bubble"
import { 
  RefreshCw, 
  Clock, 
  Package, 
  CreditCard, 
  AlertCircle,
  CheckCircle
} from "lucide-react"

export default function RefundPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <FloatingBubbles />
      
      <main className="pt-24 pb-16 px-4">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <RefreshCw className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-4xl font-bold text-foreground mb-4">Refund Policy</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We want you to be completely satisfied with your purchase. Here&apos;s everything you need to know about our refund policy.
            </p>
          </div>

          {/* Key Points */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <div className="rounded-2xl backdrop-blur-xl bg-card border border-border p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 mx-auto mb-4 flex items-center justify-center">
                <Clock className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">7-Day Return Window</h3>
              <p className="text-sm text-muted-foreground">Return within 7 days of delivery</p>
            </div>
            
            <div className="rounded-2xl backdrop-blur-xl bg-card border border-border p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 mx-auto mb-4 flex items-center justify-center">
                <Package className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Free Returns</h3>
              <p className="text-sm text-muted-foreground">No shipping charges on returns</p>
            </div>
            
            <div className="rounded-2xl backdrop-blur-xl bg-card border border-border p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 mx-auto mb-4 flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">Quick Refunds</h3>
              <p className="text-sm text-muted-foreground">Processed within 5-7 business days</p>
            </div>
          </div>

          {/* Detailed Policy */}
          <div className="space-y-6">
            <div className="rounded-3xl backdrop-blur-xl bg-card border border-border p-8">
              <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                Eligible for Refund
              </h2>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-600 mt-2 flex-shrink-0" />
                  Products received in damaged or defective condition
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-600 mt-2 flex-shrink-0" />
                  Wrong product delivered (different from what was ordered)
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-600 mt-2 flex-shrink-0" />
                  Products that are expired or near expiry upon delivery
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-600 mt-2 flex-shrink-0" />
                  Sealed products returned within 7 days of delivery
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-green-600 mt-2 flex-shrink-0" />
                  Products with manufacturing defects
                </li>
              </ul>
            </div>

            <div className="rounded-3xl backdrop-blur-xl bg-card border border-border p-8">
              <h2 className="text-xl font-semibold text-foreground mb-4 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-destructive" />
                Not Eligible for Refund
              </h2>
              <ul className="space-y-3 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-destructive mt-2 flex-shrink-0" />
                  Opened or used products (for hygiene reasons)
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-destructive mt-2 flex-shrink-0" />
                  Products without original packaging or tags
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-destructive mt-2 flex-shrink-0" />
                  Returns requested after 7 days of delivery
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-destructive mt-2 flex-shrink-0" />
                  Products marked as non-returnable or final sale
                </li>
                <li className="flex items-start gap-2">
                  <span className="w-2 h-2 rounded-full bg-destructive mt-2 flex-shrink-0" />
                  Free gifts or promotional items
                </li>
              </ul>
            </div>

            <div className="rounded-3xl backdrop-blur-xl bg-card border border-border p-8">
              <h2 className="text-xl font-semibold text-foreground mb-4">How to Request a Refund</h2>
              <ol className="space-y-4 text-muted-foreground">
                <li className="flex gap-4">
                  <span className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold flex-shrink-0">1</span>
                  <div>
                    <p className="font-medium text-foreground">Contact Customer Support</p>
                    <p className="text-sm">Call us at +91 98765 43210 or email support@bmc.com with your order details</p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <span className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold flex-shrink-0">2</span>
                  <div>
                    <p className="font-medium text-foreground">Receive Return Authorization</p>
                    <p className="text-sm">We&apos;ll review your request and send you a return authorization within 24 hours</p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <span className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold flex-shrink-0">3</span>
                  <div>
                    <p className="font-medium text-foreground">Ship the Product</p>
                    <p className="text-sm">Pack the product securely and ship it using our prepaid return label</p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <span className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold flex-shrink-0">4</span>
                  <div>
                    <p className="font-medium text-foreground">Receive Your Refund</p>
                    <p className="text-sm">Once we receive and verify the return, refund will be processed within 5-7 business days</p>
                  </div>
                </li>
              </ol>
            </div>

            <div className="rounded-3xl backdrop-blur-xl bg-primary/5 border border-primary/20 p-8">
              <h2 className="text-xl font-semibold text-foreground mb-4">Refund Methods</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-muted-foreground">
                <div>
                  <p className="font-medium text-foreground mb-1">Online Payments</p>
                  <p className="text-sm">Refunded to original payment method (Card/UPI)</p>
                </div>
                <div>
                  <p className="font-medium text-foreground mb-1">Cash on Delivery</p>
                  <p className="text-sm">Refunded via bank transfer or BMC wallet credits</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
