"use client"

import { use, useState } from "react"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FloatingBubbles } from "@/components/glass-bubble"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"
import { shops, products, categories } from "@/lib/products-data"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { cn } from "@/lib/utils"
import { notFound } from "next/navigation"

export default function ShopPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params)
  const [selectedCategory, setSelectedCategory] = useState("All")
  
  const shop = shops.find(s => s.id === id)
  
  if (!shop) {
    notFound()
  }
  
  const shopProducts = products.filter(p => p.shop === id)
  const filteredProducts = selectedCategory === "All" 
    ? shopProducts 
    : shopProducts.filter(p => p.category === selectedCategory)

  return (
    <div className="min-h-screen">
      <Header />
      <FloatingBubbles />
      
      <main className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back button */}
          <Link href="/shops">
            <Button variant="ghost" className="mb-6">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Shops
            </Button>
          </Link>

          {/* Shop Header */}
          <div className="relative overflow-hidden rounded-3xl backdrop-blur-xl bg-card border border-border p-8 mb-8">
            {/* Decorative bubbles */}
            <div className="absolute -top-12 -right-12 w-40 h-40 rounded-full bg-primary/10 backdrop-blur-sm" />
            <div className="absolute -bottom-8 -left-8 w-32 h-32 rounded-full bg-accent/10 backdrop-blur-sm" />
            
            <div className="relative z-10 flex flex-col md:flex-row items-center gap-6">
              <div className={cn(
                "w-24 h-24 rounded-2xl bg-gradient-to-br flex items-center justify-center",
                shop.color
              )}>
                <span className="text-4xl font-bold text-white">{shop.name.charAt(0)}</span>
              </div>
              <div className="text-center md:text-left">
                <h1 className="text-3xl font-bold text-foreground mb-2">{shop.name}</h1>
                <p className="text-muted-foreground">{shop.description}</p>
                <p className="text-sm text-primary mt-2">{shopProducts.length} Products Available</p>
              </div>
            </div>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap gap-2 mb-8">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="rounded-full"
              >
                {category}
              </Button>
            ))}
          </div>

          {/* Products Grid */}
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No products found in this category.</p>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}
