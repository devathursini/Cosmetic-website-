"use client"

import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FloatingBubbles } from "@/components/glass-bubble"
import { ShopCard } from "@/components/shop-card"
import { shops } from "@/lib/products-data"

export default function ShopsPage() {
  return (
    <div className="min-h-screen">
      <Header />
      <FloatingBubbles />
      
      <main className="pt-24 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-foreground mb-4">Our Partner Brands</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Explore our collection of premium cosmetic brands. Each brand offers unique products tailored to enhance your natural beauty.
            </p>
          </div>

          {/* Shops Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {shops.map((shop) => (
              <ShopCard key={shop.id} {...shop} />
            ))}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
