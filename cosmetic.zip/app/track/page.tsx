"use client"

import React from "react"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams } from "next/navigation"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FloatingBubbles } from "@/components/glass-bubble"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { 
  Package, 
  CheckCircle, 
  Truck, 
  MapPin, 
  Search,
  Clock
} from "lucide-react"
import { cn } from "@/lib/utils"

interface Order {
  id: string
  items: Array<{ name: string; quantity: number }>
  total: number
  address: {
    fullName: string
    phone: string
    address: string
    city: string
    state: string
    pincode: string
  }
  paymentMethod: string
  status: string
  date: string
}

const trackingSteps = [
  { id: 1, name: "Order Confirmed", icon: CheckCircle },
  { id: 2, name: "Processing", icon: Package },
  { id: 3, name: "Shipped", icon: Truck },
  { id: 4, name: "Delivered", icon: MapPin },
]

function TrackOrderContent() {
  const searchParams = useSearchParams()
  const initialOrderId = searchParams.get("orderId") || ""
  
  const [orderId, setOrderId] = useState(initialOrderId)
  const [searchId, setSearchId] = useState(initialOrderId)
  const [order, setOrder] = useState<Order | null>(null)
  const [notFound, setNotFound] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)

  useEffect(() => {
    if (searchId) {
      // Get orders from localStorage
      const orders = JSON.parse(localStorage.getItem("bmc-orders") || "[]")
      const foundOrder = orders.find((o: Order) => o.id === searchId)
      
      if (foundOrder) {
        setOrder(foundOrder)
        setNotFound(false)
        // Simulate progress based on time
        const orderTime = new Date(foundOrder.date).getTime()
        const now = Date.now()
        const hoursPassed = (now - orderTime) / (1000 * 60 * 60)
        
        if (hoursPassed < 1) setCurrentStep(1)
        else if (hoursPassed < 24) setCurrentStep(2)
        else if (hoursPassed < 72) setCurrentStep(3)
        else setCurrentStep(4)
      } else {
        setOrder(null)
        setNotFound(true)
      }
    }
  }, [searchId])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setSearchId(orderId)
  }

  return (
    <div className="min-h-screen">
      <Header />
      <FloatingBubbles />
      
      <main className="pt-24 pb-16 px-4">
        <div className="max-w-3xl mx-auto">
          {/* Search Box */}
          <div className="relative overflow-hidden rounded-3xl backdrop-blur-xl bg-card/80 border border-border p-8 mb-8">
            <div className="absolute -top-12 -right-12 w-32 h-32 rounded-full bg-primary/10 backdrop-blur-sm" />
            <div className="absolute -bottom-8 -left-8 w-24 h-24 rounded-full bg-accent/10 backdrop-blur-sm" />
            
            <div className="relative z-10">
              <div className="text-center mb-6">
                <h1 className="text-3xl font-bold text-foreground mb-2">Track Your Order</h1>
                <p className="text-muted-foreground">Enter your order ID to see the delivery status</p>
              </div>
              
              <form onSubmit={handleSearch} className="flex gap-3 max-w-md mx-auto">
                <Input
                  placeholder="Enter Order ID (e.g., BMC12345678)"
                  value={orderId}
                  onChange={(e) => setOrderId(e.target.value)}
                  className="flex-1"
                />
                <Button type="submit">
                  <Search className="w-4 h-4 mr-2" />
                  Track
                </Button>
              </form>
            </div>
          </div>

          {/* Not Found */}
          {notFound && (
            <div className="rounded-3xl backdrop-blur-xl bg-card/80 border border-border p-8 text-center">
              <div className="w-16 h-16 rounded-full bg-destructive/10 mx-auto mb-4 flex items-center justify-center">
                <Package className="w-8 h-8 text-destructive" />
              </div>
              <h2 className="text-xl font-semibold text-foreground mb-2">Order Not Found</h2>
              <p className="text-muted-foreground">
                We couldn&apos;t find an order with ID &quot;{searchId}&quot;. Please check and try again.
              </p>
            </div>
          )}

          {/* Order Details */}
          {order && (
            <div className="space-y-6">
              {/* Tracking Progress */}
              <div className="rounded-3xl backdrop-blur-xl bg-card/80 border border-border p-8">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-xl font-semibold text-foreground">Order #{order.id}</h2>
                    <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                      <Clock className="w-4 h-4" />
                      Placed on {new Date(order.date).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric'
                      })}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Total</p>
                    <p className="text-xl font-bold text-foreground">Rs {Math.round(order.total).toLocaleString('en-IN')}</p>
                  </div>
                </div>
                
                {/* Progress Steps */}
                <div className="relative">
                  <div className="absolute top-5 left-0 right-0 h-0.5 bg-secondary" />
                  <div 
                    className="absolute top-5 left-0 h-0.5 bg-primary transition-all duration-500" 
                    style={{ width: `${((currentStep - 1) / (trackingSteps.length - 1)) * 100}%` }}
                  />
                  
                  <div className="relative flex justify-between">
                    {trackingSteps.map((step) => (
                      <div key={step.id} className="flex flex-col items-center">
                        <div className={cn(
                          "w-10 h-10 rounded-full flex items-center justify-center transition-all",
                          currentStep >= step.id
                            ? "bg-primary text-primary-foreground"
                            : "bg-secondary text-muted-foreground"
                        )}>
                          <step.icon className="w-5 h-5" />
                        </div>
                        <span className={cn(
                          "mt-2 text-xs text-center max-w-[80px]",
                          currentStep >= step.id ? "text-foreground font-medium" : "text-muted-foreground"
                        )}>
                          {step.name}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Order Items */}
              <div className="rounded-3xl backdrop-blur-xl bg-card/80 border border-border p-6">
                <h3 className="font-semibold text-foreground mb-4">Order Items</h3>
                <div className="space-y-3">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 rounded-xl bg-secondary/30">
                      <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center">
                        <span className="text-sm font-bold text-primary/40">{item.name.charAt(0)}</span>
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-foreground">{item.name}</p>
                        <p className="text-sm text-muted-foreground">Quantity: {item.quantity}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Delivery Address */}
              <div className="rounded-3xl backdrop-blur-xl bg-card/80 border border-border p-6">
                <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  Delivery Address
                </h3>
                <div className="text-muted-foreground">
                  <p className="font-medium text-foreground">{order.address.fullName}</p>
                  <p>{order.address.address}</p>
                  <p>{order.address.city}, {order.address.state} - {order.address.pincode}</p>
                  <p className="mt-2">Phone: {order.address.phone}</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  )
}

export default function TrackPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    }>
      <TrackOrderContent />
    </Suspense>
  )
}
