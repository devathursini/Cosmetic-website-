"use client"

import React from "react"

import { cn } from "@/lib/utils"

interface GlassBubbleProps {
  className?: string
  children?: React.ReactNode
  variant?: "default" | "accent" | "muted"
  size?: "sm" | "md" | "lg" | "xl"
  animated?: boolean
}

export function GlassBubble({
  className,
  children,
  variant = "default",
  size = "md",
  animated = false,
}: GlassBubbleProps) {
  const sizeClasses = {
    sm: "w-16 h-16",
    md: "w-24 h-24",
    lg: "w-32 h-32",
    xl: "w-48 h-48",
  }

  const variantClasses = {
    default: "bg-primary/20 border-primary/30",
    accent: "bg-accent/20 border-accent/30",
    muted: "bg-muted/40 border-muted/50",
  }

  return (
    <div
      className={cn(
        "rounded-full backdrop-blur-md border",
        sizeClasses[size],
        variantClasses[variant],
        animated && "animate-float",
        className
      )}
    >
      {children && (
        <div className="w-full h-full flex items-center justify-center">
          {children}
        </div>
      )}
    </div>
  )
}

export function FloatingBubbles() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden -z-10">
      <GlassBubble
        size="xl"
        variant="default"
        animated
        className="absolute top-20 left-10 opacity-40"
        style={{ animationDelay: "0s" } as React.CSSProperties}
      />
      <GlassBubble
        size="lg"
        variant="accent"
        animated
        className="absolute top-40 right-20 opacity-30"
        style={{ animationDelay: "1s" } as React.CSSProperties}
      />
      <GlassBubble
        size="md"
        variant="muted"
        animated
        className="absolute bottom-40 left-1/4 opacity-35"
        style={{ animationDelay: "2s" } as React.CSSProperties}
      />
      <GlassBubble
        size="lg"
        variant="default"
        animated
        className="absolute bottom-20 right-1/3 opacity-25"
        style={{ animationDelay: "0.5s" } as React.CSSProperties}
      />
      <GlassBubble
        size="sm"
        variant="accent"
        animated
        className="absolute top-1/3 left-1/2 opacity-40"
        style={{ animationDelay: "1.5s" } as React.CSSProperties}
      />
      <GlassBubble
        size="md"
        variant="default"
        animated
        className="absolute top-2/3 right-10 opacity-30"
        style={{ animationDelay: "2.5s" } as React.CSSProperties}
      />
    </div>
  )
}
