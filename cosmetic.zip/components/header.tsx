"use client"

import Link from "next/link"
import { ShoppingCart, User, Menu, X, Search } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart } from "@/context/cart-context"
import { useState } from "react"
import { cn } from "@/lib/utils"

export function Header() {
  const { itemCount } = useCart()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-card border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="relative">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">B</span>
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-accent/60 backdrop-blur-sm" />
            </div>
            <span className="text-xl font-bold text-foreground">BMC</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-foreground/80 hover:text-primary transition-colors font-medium">
              Home
            </Link>
            <Link href="/shops" className="text-foreground/80 hover:text-primary transition-colors font-medium">
              Shops
            </Link>
            <Link href="/offers" className="text-foreground/80 hover:text-primary transition-colors font-medium">
              Offers
            </Link>
            <Link href="/track" className="text-foreground/80 hover:text-primary transition-colors font-medium">
              Track Order
            </Link>
            <Link href="/contact" className="text-foreground/80 hover:text-primary transition-colors font-medium">
              Contact
            </Link>
          </nav>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="hidden md:flex">
              <Search className="w-5 h-5" />
            </Button>
            <Link href="/cart">
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="w-5 h-5" />
                {itemCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </Button>
            </Link>
            <Link href="/signin">
              <Button variant="ghost" size="icon">
                <User className="w-5 h-5" />
              </Button>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div
          className={cn(
            "md:hidden overflow-hidden transition-all duration-300",
            mobileMenuOpen ? "max-h-64 pb-4" : "max-h-0"
          )}
        >
          <nav className="flex flex-col gap-2">
            <Link href="/" className="px-4 py-2 rounded-lg hover:bg-secondary text-foreground/80 hover:text-primary transition-colors">
              Home
            </Link>
            <Link href="/shops" className="px-4 py-2 rounded-lg hover:bg-secondary text-foreground/80 hover:text-primary transition-colors">
              Shops
            </Link>
            <Link href="/offers" className="px-4 py-2 rounded-lg hover:bg-secondary text-foreground/80 hover:text-primary transition-colors">
              Offers
            </Link>
            <Link href="/track" className="px-4 py-2 rounded-lg hover:bg-secondary text-foreground/80 hover:text-primary transition-colors">
              Track Order
            </Link>
            <Link href="/contact" className="px-4 py-2 rounded-lg hover:bg-secondary text-foreground/80 hover:text-primary transition-colors">
              Contact
            </Link>
          </nav>
        </div>
      </div>
    </header>
  )
}
