"use client"

import { Plus, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useCart, type Product } from "@/context/cart-context"
import { cn } from "@/lib/utils"
import { useState } from "react"

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const { addToCart, items } = useCart()
  const [justAdded, setJustAdded] = useState(false)
  
  const isInCart = items.some(item => item.id === product.id)
  const discountedPrice = product.discount
    ? product.price * (1 - product.discount / 100)
    : product.price

  const handleAddToCart = () => {
    addToCart(product)
    setJustAdded(true)
    setTimeout(() => setJustAdded(false), 1500)
  }

  return (
    <div className="group relative overflow-hidden rounded-2xl backdrop-blur-xl bg-card border border-border p-4 transition-all duration-300 hover:shadow-lg hover:shadow-primary/10">
      {/* Discount badge */}
      {product.discount && (
        <div className="absolute top-3 left-3 z-10 px-2 py-1 rounded-full bg-destructive text-destructive-foreground text-xs font-semibold">
          {product.discount}% OFF
        </div>
      )}
      
      {/* Bubble decoration */}
      <div className="absolute -top-6 -right-6 w-16 h-16 rounded-full bg-primary/5 backdrop-blur-sm" />
      
      {/* Product image placeholder */}
      <div className="relative aspect-square rounded-xl bg-gradient-to-br from-secondary to-muted mb-4 overflow-hidden">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center">
            <span className="text-3xl font-bold text-primary/60">{product.name.charAt(0)}</span>
          </div>
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-foreground/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>
      
      {/* Product info */}
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground uppercase tracking-wide">{product.category}</p>
        <h3 className="font-medium text-foreground line-clamp-2 min-h-[2.5rem]">{product.name}</h3>
        
        <div className="flex items-center gap-2">
          <span className="text-lg font-bold text-foreground">
            Rs {Math.round(discountedPrice).toLocaleString('en-IN')}
          </span>
          {product.discount && (
            <span className="text-sm text-muted-foreground line-through">
              Rs {product.price.toLocaleString('en-IN')}
            </span>
          )}
        </div>
        
        <Button
          onClick={handleAddToCart}
          className={cn(
            "w-full mt-2 transition-all duration-300",
            justAdded && "bg-green-600 hover:bg-green-700"
          )}
          size="sm"
        >
          {justAdded ? (
            <>
              <Check className="w-4 h-4 mr-2" />
              Added!
            </>
          ) : (
            <>
              <Plus className="w-4 h-4 mr-2" />
              Add to Cart
            </>
          )}
        </Button>
      </div>
    </div>
  )
}
