"use client"

import Link from "next/link"
import { ArrowRight } from "lucide-react"
import { cn } from "@/lib/utils"

interface ShopCardProps {
  id: string
  name: string
  description: string
  color: string
}

export function ShopCard({ id, name, description, color }: ShopCardProps) {
  return (
    <Link href={`/shop/${id}`}>
      <div className="group relative overflow-hidden rounded-2xl backdrop-blur-xl bg-card border border-border p-6 transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-primary/10">
        {/* Gradient overlay */}
        <div className={cn(
          "absolute inset-0 opacity-10 group-hover:opacity-20 transition-opacity bg-gradient-to-br",
          color
        )} />
        
        {/* Bubble decoration */}
        <div className="absolute -top-4 -right-4 w-20 h-20 rounded-full bg-primary/10 backdrop-blur-sm" />
        <div className="absolute -bottom-6 -left-6 w-16 h-16 rounded-full bg-accent/10 backdrop-blur-sm" />
        
        <div className="relative z-10">
          {/* Shop logo placeholder */}
          <div className={cn(
            "w-16 h-16 rounded-xl bg-gradient-to-br mb-4 flex items-center justify-center",
            color
          )}>
            <span className="text-2xl font-bold text-white">{name.charAt(0)}</span>
          </div>
          
          <h3 className="text-xl font-semibold text-foreground mb-2">{name}</h3>
          <p className="text-muted-foreground text-sm mb-4">{description}</p>
          
          <div className="flex items-center text-primary font-medium group-hover:gap-2 transition-all">
            <span>Shop Now</span>
            <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>
    </Link>
  )
}
